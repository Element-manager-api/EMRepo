export enum LogErrorType {
  Error = 'Error',
  Warn = 'Warn',
  Debug = 'Debug',
  Trace = 'Trace',
  Info = 'Info'
}
