export interface IAccountInfo {
   firstName: string;
   lastName: string;
   email: string;
}
