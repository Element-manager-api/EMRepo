export interface IContactResponse {
  id: number,
  lookupName: string
}
